
*Only second question code.
Input Format:
  Due to inconvience only one tree at a time input is taken.
  but input should be of the form:
  first enter buffer number of lines eg.4 (but code is for 1 tree at a time)
  then enter inorder traversal of the tree in the next line.
  Then in the next line preorder traversal of the tree.
  in the next lines(until your total lines are upper buffer number) some buffer value should be entered like 6 and click enter.
Output:
    Corresponding tree format(array format) is printed.