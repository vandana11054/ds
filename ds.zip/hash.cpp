

#include<iostream>
#include<fstream>
#include<string>
#include<cstdlib>
#include<time.h>
using namespace std;
int count = 0;
struct node{
    int key;
    string name;
    string email;
    string gender;
};

int uhash(int key,int m){
    int a=0;
    int b=0;
    int p=5003;
    a = rand()%(1000)+1;
    b = 1+rand()%(1000);
    // cout<<a<<" ";
    // cout<<b<<" ";
    // cout<< a*key+b<< " ";
    return ((a*key+b)%p)%m;
}
int main()
{
    int val=0;
    cin>>val;
    srand(time(0));
    node* arr[5000]={0};
    int dat[1000]={0};
    int collision[1000]={0};
    int merges = 0;
    string line;
    string a;
    string b;
    string c;
    string d;
    string e;
    int index;
    int last;
    ifstream obj("data.txt");
    do{
    count=0;
    while(!obj.eof()){
    getline(obj,line);
    if(!(line.empty())){
    int i=0;
    for(;i<line.length();i++){
        if(!(isspace(line[i]))){
            a.push_back(line[i]);
        }else break;
    }
    i++;
     for(;i<line.length();i++){
        if(!(isspace(line[i]))){
            b.push_back(line[i]);
        }else break;
    }
    i++;
     for(;i<line.length();i++){
        if(!(isspace(line[i]))){
            c.push_back(line[i]);
        }else break;
    }
    i++;
     for(;i<line.length();i++){
        if(!(isspace(line[i]))){
            d.push_back(line[i]);
        }else break;
    }
    i++;
      for(;i<line.length();i++){
        if(!(isspace(line[i]))){
            e.push_back(line[i]);
        }else break;
      }
     int k = stoi(a);
     index = uhash(k,5000);
     dat[index] +=1;
     struct node one;
     one.key = stoi(a);
     one.name = c;
     one.email = d;
     one.gender =e;
    //  cout<<dat[index]<<" ";
     if(arr[index]==0){
     arr[index] = &one;
     }else{
       collision[merges] = k;
       merges++;
     }
     a.erase();
     b.erase();
     c.erase();
     d.erase();
     e.erase();
    }
    }
    for(int i=0;i<1000;i++){
        count += dat[i];
    }
    for(int i=0;i<1000;i++){
        if(collision[i]!=0) {
           int curr = uhash(collision[i],count);
           *arr[curr] = *arr[collision[i]]; 
        }
    }
    }while((10*count*count)>5000);
    obj.close(); 
    cout << (arr[val]->email);
    return 0;
}
