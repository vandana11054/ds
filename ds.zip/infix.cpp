

#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
 
int opush(char a[],int b,char c,int len){
    if(b== len) return 999;
    else{
        a[b]= c;
         b++;
    }
    return b;
}
char opop(char a[],int b){
    if(b==0) return '!';
    else{
        b--;
    }
    return a[b+1];
} 
int fpush(char a[],int b,char c,int len){
    if(b== len) return 999;
    else{
        a[b]= c;
        b++;
    }
    return b;
}
char fpop(char a[],int b){
    if(b==0) return '!';
    else{
        b--;
    }
    return a[b+1];
} 
int main(){
    int operTop=0;
    int funcTop=0;
    int count;
    cin>>count;
    cout<<endl;
    while(count>=0){         //Answer dispalyed exactly for one input handling to multiple lines is becoming 
    //problematic.
        string in;
        getline(cin,in);
        count--; 
        string out;
        char oper[30] = {0};
        char func[30] = {0}; 
        int icount=0;
        int fcount =0;
        for(int i=0;i<in.length();i++){
             if((int)in[i]>=96 && (int)in[i]<=122 && !isspace(in[i])){
               operTop = opush(oper,operTop,in[i],in.length());
               icount++;
             }     
             else if(!isspace(in[i])) {
                funcTop = fpush(func,funcTop,in[i],in.length());
                fcount++; 
             }
        }
        for(int i=0;i<=in.length();i=i+1){
            if(fcount>0 || icount>0){
               out.push_back(func[fcount-1]);
               out.push_back(oper[icount-1]);   
               icount--;
               fcount--;
            }
        }
            reverse(out.begin(),out.end());
            cout<<out<<endl;
    }
     return 0;
}    
