

#include<iostream>
#include<bits/stdc++.h>
#include<string>
#include<stdlib.h>
using namespace std;
struct node{
    int data;
    struct node* left;
    struct node* right;
};

struct node* createNode(struct node* item,int key){
    struct node* one =(struct node*)malloc(sizeof(struct node));
    one->data = key;
    one->left = NULL;
    one->right = NULL;
    item = one;
    return item;
}

struct node* insert(struct node* item,int key){
 if(item == NULL){
      item = createNode(item,key);
    return item;
 }
 return item;
}
struct node* tree(int p,int i,int* in,int* pre,struct node* elem,int pin,int idx,struct node* root,int sub){
        if(p==0) elem = root; 
       static int f=0;
        if(elem == NULL) return elem;
        for(int l=0;l<idx;l++){                                     /*  Recursive function to print tree except root*/
            if(in[l]==pre[p]){                           
                  sub=l;
            }
        }
        if(f==0){
        for(int l=0;l<sub;l++){
            if(in[l]==pre[p+1]){
                  elem->left = insert(elem->left,pre[p+1]);
                  std::cout<<pre[p+1]<<" ";
                  elem->right = insert(elem->right,pre[p+sub+1]);
                  std::cout<<pre[p + sub +1]<<" ";
            }
        }
        }
        if(f==1){
        for(int l=sub-1;l>=0;l--){
            if(in[l]==pre[p+1]){
                  elem->left = insert(elem->left,pre[p+sub+2]);
                  std::cout<<pre[p+3+sub]<<" ";
                  elem->right = insert(elem->right,pre[p+sub+3]);
                  std::cout<<pre[p+4+sub]<<" ";
            }
        }
        }
        p++;
        if(p>=pin) return elem;
         if(elem->left != NULL){
               elem->left = tree(p,i,in,pre,elem->left,pin,idx,root,sub);
         }
         if(elem->right != NULL){
              f=1;
              elem->right = tree(p,i,in,pre,elem->right,pin,idx,root,sub);
              f=0;
         }
     return elem;
}
int main(){
    int num;
    cin>>num;        
    int trees;
    string line;
    num++;
    string lines[num];
    int i=0;
    int in[20];
    int pre[20];
    while(num>0){
          getline(cin,line);
         if(!line.empty()) 
           lines[i] = line;          /*Took input*/
          i++;
          num--;
    }
    int t=1;
    int idx=0;
    for(int i=0;i<lines[t].length();i++){
        if(!isspace(lines[t][i])) {
            in[idx] = lines[t][i] - '0'; 
            idx++;
        }
    }
    int pin =0;
    for(int i=0;i<lines[t].length();i++){
        if(!isspace(lines[t+1][i])) {
            pre[pin] = lines[t+1][i] - '0'; 
            pin++;
        }
    }
     struct node* root = NULL;
     int ic=0;
     int p=0;
     int sub=0;
     root = insert(root,pre[p]);
     cout<<root->data<<"  ";
     struct node* elem;
     elem = tree(p,ic,in,pre,elem,pin,idx,root,sub); /*Remaining tree is printed*/
     cout<<endl;
    return 0;
}