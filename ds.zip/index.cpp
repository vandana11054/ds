
//Program for separating even and odd indices of an array
#include<iostream>
#include<cstdlib>
#include<string>
using namespace std;
struct list{                  //each element of linked list is a struct(data and ptr to previous element)
   int key;
   struct list* addr;
};
struct list* create(int a,struct list* b){        //function for creating a struct with inputs data and head ptr
   struct list* one = (struct list*)malloc(sizeof(struct list));
   one->key = a;                 
   one->addr = b;
   return one;        //pointer to current element(data and head ptr) is returned.
}

int main(){
    int count =0;
    cin>>count;              //count is Number of lines of execution
    int  counter = count;    // counter variable to output answer
    string answer[count];    //An array for storing each line of input
   do{
    string input;           //Each individual line of input is stored in  string input
    struct list* head=NULL;   //before creating list head points to NULL 
    getline(cin,input);        //array input
    for(int i=0;i<input.length();i++){
        if(!isspace(input[i]) && input[i]!=','){   //if input is a character other than space and ','
           if(i%2==0) {                            //even indiced element(0,2,4,6,...)
               head = create(input[i],head);     //creating list item & storing it's pointer to head of next item
                answer[count].push_back((char)head->key); //pushing element key value to answer string
                answer[count].push_back(32);         //pushing empty space to answer string
                //cout<<head<<endl;                  can be printed to verify storing in linked list
           } 
        }
    }
   for(int i=0;i<input.length();i++){
        if(!isspace(input[i]) && input[i]!=','){
           if(i%2==1) {                       //odd indiced element(1,3,5,7,...)
               head = create(input[i],head);  //creating list item & storing it's pointer to head of next item
                answer[count].push_back((char)head->key); //pushing element key value to answer string
                answer[count].push_back(32);  //pushing empty space to answer string
               //cout<<head<<endl;                  can be printed to verify storing in linked list
            } 
        }
   }
   count--;
   }while(count>=0);

   for(int m=counter-1;m>=0;m--){
      cout<<answer[m]<<endl;        //answer(string of arrays) is printed linewise
   }
   

 return 0;
}