

#include <iostream>
#include <vector>
#include <string>
#include  <bits/stdc++.h>
using  namespace std;
int main(){
   //    vector<string> vec;
   //    string str;
   //   while(getline(cin,str)){
   //      if(str.empty()){
   //       break;
   //      }else{
   //          vec.push_back(str);
   //      }
   //   }
   //   char line=0;
   //   int num=0;
   //   for (string it : vec){
   //     if(line == 0){
   //        num = stoi(it);   
   //     }
   //     else{
   //     for(int i=0;i<num;i++){
   //           int a=0;
   //           int b=0;
   //           int stop =0;
   //         for(int k=0;k<it.length();k++){
   //            if((isspace(it[k]))){
   //                 stop = k;
   //            }
   //            if(k<stop){
   //               a= a + (int)(it[k]-'0')*(pow(10.0,stop-k-1));
   //            }
   //            if(k>stop){
   //             b= b + (int)(it[k]-'0')*(pow(10.0,it.length()-k));
   //            }
   //          }
   //          cout<<a<<"^";
   //          cout<<b<<"*"<<endl;
   //         }
   //     }
   //      line++;
   //     }
    return 0;
}
