
**Functioning of index.cpp:**
    User inputs a collection of arrays and code returns a linked list of each array with odd indiced elements followed by even indiced elements of that given array.

**Input Format:**
    first input number of arrays (hit enter)
    and then input each array line by line
    Format of array:  item1, item2, item3, item4,....
    every element is seperated by a comma followed by one white-space character
    (Considered every element is a single-digit)

**Output:**
    Each linked list is printed with space among individual elements on separate line for each array.

**Working:**
  struct list creates a structure of a integer and list pointer.(self-referencial property)  
  struct list create() creates a list element and assigns data value,head pointer to it and returns 
  it's address
  Inside main function,a loop goes through each line of array in which even indices are added to linked list first then again loop runs through each line for storing odd elements. 