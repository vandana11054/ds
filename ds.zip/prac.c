

#include<stdio.h>
#include<stdlib.h>
struct node{
  int val1;
  int val2;
  int val3;
  struct node* p;      //Each node of the tree has a parent node and 4 child nodes
  struct node* c1;
  struct node* c2;
  struct node* c3;
  struct node* c4;
};
struct node * createNode(int x,int y,int z,struct node* p1){
      struct node* item = (struct node*)malloc(sizeof(struct node));
      item->val1 = x;
      item->val2 = y;
      item->val3 = z;   //empty integer values of node are initialised with -1
      item->p = p1;
      item->c1 = NULL;
      item->c2 = NULL;
      item->c3 = NULL;
      item->c4 = NULL;
}
struct node* insert(int key,struct node* item){
    static int ins = 0;      //variable to check if the loop is in recursive call or not
    int leaf=0;   
    static int match = 0;     //variable to stop infinite loop in break and promote case
    static int promote = 0;   //variable to check if current node needs to add promoted element or not
     if(item == NULL){
        return createNode(key,-1,-1,NULL);
     }
     if(item->c1 == NULL && item->c2 == NULL && item->c3 == NULL && item->c4 == NULL ) leaf=1; //leaf node
     //if node is not leaf and not promote then go to required child node acc. to key's numeric value.
     if(key<item->val1 && !leaf && !promote) {
        item->c1 = insert(key,item->c1); 
        ins = key;
     }
     if(item->val2 == -1 && item->val3 == -1 && key>item->val1 && !leaf  && !promote){
       item->c2 = insert(key,item->c2);
        ins = key;
     }
     if(key>item->val3 && !leaf && item->val3 != -1 && !promote) {
      item->c4 = insert(key,item->c4);
       ins = key;
     }
     if(key>item->val1 && key<item->val2 && item->c2 != NULL  && item->val2 != -1 && !leaf  && !promote){
      item->c2 = insert(key,item->c2);
       ins = key;
     }
     if(key>item->val2 && key<item->val3 && item->c3 != NULL  && item->val3 != -1 && !leaf  && !promote){
        item->c3 =  insert(key,item->c3);
        ins = key;
     }
     //Insert operation:
    if(item->val1 == -1 && (leaf||promote) && ins!=key) {
      item->val1 = key;
      return item;
    }
    else if(item->val2 == -1 && (promote|| leaf) && ins!=key){
       if(key>item->val1) item->val2 = key;
       else{
        item->val2 = item->val1;
        item->val1 =key;
       } 
       return item;
    }else if(item->val3 == -1 && (leaf||promote) && ins!=key ){
      if(item->val1 > key){
        item->val3 = item->val2;
        item->val2 = item->val1;
        item->val1 = key;
      }
      else if(key > item->val2 && key<item->val1 && (leaf||promote) && ins!=key) item->val3 = key;
      else{
      item->val3 = item->val2;
      item->val2 = key;
      }
       return item;
    }
     else if(ins != key) /* signifies case :item->val1 !=-1 && item->val2 !=-1 && item->val3 !=-1 && leaf */{
      //Case of break and promote
      if(item->p != NULL && match==0){
       match = key  ; 
       promote=1;
       item->p = insert(item->val2,item->p);
      }
      match =0 ;
      promote =0;
       if(item->p == NULL){    //if parent is NULL for a break and promote case
        item->p = createNode(item->val2,-1,-1,NULL);
        item->p->c1 = item;
        //Already existing children are moved right further and key is inserted in it's position.
         if(key<item->val1){
          item->val2 = item->val1;
          item->val1 =key;
          if(item->p->c2 == NULL)  item->p->c2 = createNode(item->val3,-1,-1,item->p);
          else item->p->c2->val1 = item->val3;
          item->p->c2->val2 = -1;
          item->p->c2->val3 = -1;
          item->val3 = -1;
        }else if(key > item->val1 && key< item->val2){
          item->val2 = key;
           if(item->p->c2 == NULL)  item->p->c2 = createNode(item->val3,-1,-1,item->p);
           else item->p->c2->val1 = item->val3;
          item->p->c2->val2 = -1;
          item->p->c2->val3 = -1;
          item->val3 = -1;
        }else if(key > item->val2 && key< item->val3){
          item->val2 =-1;
          if(item->p->c2 == NULL)  item->p->c2 = createNode(key,-1,-1,item->p);
          else item->p->c2->val1 = key;
          item->p->c2->val2 = item->val3;
          item->p->c2->val3 = -1;
          item->val3 = -1;
        }else if(key>item->val3){
          if(item->p->c2 == NULL)  item->p->c2 = createNode(item->val3,-1,-1,item->p);
          else item->p->c2->val1 = item->val3;
          item->p->c2->val2 = key;
          item->val2 = -1;
          item->val3 = -1;
        }
        return item->p;
      }
      if(item->p->c1 == item && item->p != NULL && ins != key ){ //if item is 1st child of parent node.
         //Already existing children are moved right further and key is inserted in it's position.
        if(item->p->c3 != NULL) item->p->c4 = item->p->c3;
        if(item->p->c2 != NULL) item->p->c3 = item->p->c2;
        if(key<item->val1){
          item->val2 = item->val1;
          item->val1 =key;
          if(item->p->c2 == NULL)  item->p->c2 = createNode(item->val3,-1,-1,item->p);
          else item->p->c2->val1 = item->val3;
          item->p->c2->val2 = -1;
          item->p->c2->val3 = -1;
          item->val3 = -1;
        }else if(key > item->val1 && key< item->val2){
          item->val2 = key;
          if(item->p->c2 == NULL)  item->p->c2 = createNode(item->val3,-1,-1,item->p);
          else item->p->c2->val1 = item->val3;
          item->p->c2->val2 = -1;
          item->p->c2->val3 = -1;
          item->val3 = -1;
        }else if(key > item->val2 && key< item->val3){
          item->val2 =-1;
          if(item->p->c2 == NULL)  item->p->c2 = createNode(key,-1,-1,item->p);
          else item->p->c2->val1 = key;
          item->p->c2->val2 = item->val3;
          item->p->c2->val3 = -1;
          item->val3 = -1;
        }else if(key>item->val3){
          if(item->p->c2 == NULL)  item->p->c2 = createNode(item->val3,-1,-1,item->p);
          else item->p->c2->val1 = item->val3;
          item->p->c2->val2 = key;
          item->val2 = -1;
          item->val3 = -1;
        }
         match = 0;
         return item;
      }else if(item->p->c2 == item  && item->p != NULL && ins != key ){ //if item is 2nd child of parent node.
        if(item->p->c3 != NULL) item->p->c4 = item->p->c3;
        if(key<item->val1){
          item->val2 = item->val1;
          item->val1 =key;
          if(item->p->c3 == NULL)  item->p->c3 = createNode(item->val3,-1,-1,item->p);
          else item->p->c3->val1 = item->val3;
          item->p->c3->val2 = -1;
          item->p->c3->val3 = -1;
          item->val3 = -1;
        }else if(key > item->val1 && key< item->val2 && item->val2!=-1){
          item->val2 = key;
          if(item->p->c3 == NULL)  item->p->c3 = createNode(item->val3,-1,-1,item->p);
          else item->p->c3->val1 = item->val3;
          item->p->c3->val2 = -1;
          item->p->c3->val3 = -1;
          item->val3 = -1;
        }else if(key > item->val2 && key< item->val3  && item->val2!=-1  && item->val3!=-1){
          item->val2 =-1;
          if(item->p->c3 == NULL)  item->p->c3 = createNode(key,-1,-1,item->p);
          else item->p->c3->val1 = key;
          item->p->c3->val2 = item->val3;
          item->p->c3->val3 = -1;
          item->val3 = -1;
        }else if(key>item->val3  && item->val3!=-1){
          if(item->p->c3 == NULL)  item->p->c3 = createNode(item->val3,-1,-1,item->p);
          else item->p->c3->val1 = item->val3;
          item->p->c2->val2 = key;
          item->val2 = -1;
          item->val3 = -1;
        }
        match = 0;
        promote =0;
        return item;
      }else if(item->p->c3 == item  && item->p != NULL && ins != key ){ //if item is 3rd child of parent node.
        if(key<item->val1){
          item->val2 = item->val1;
          item->val1 =key;
          if(item->p->c4 == NULL)  item->p->c4 = createNode(item->val3,-1,-1,item->p);
          else item->p->c4->val1 = item->val3;
          item->p->c4->val2 = -1;
          item->p->c4->val3 = -1;
          item->val3 = -1;
        }else if(key > item->val1 && key< item->val2  && item->val2!=-1){
          item->val2 = key;
          if(item->p->c4 == NULL)  item->p->c4 = createNode(item->val3,-1,-1,item->p);
          else item->p->c4->val1 = item->val3;
          item->p->c4->val2 = -1;
          item->p->c4->val3 = -1;
          item->val3 = -1;
        }else if(key > item->val2 && key< item->val3  && item->val3!=-1  && item->val2!=-1){
          item->val2 =-1;
          if(item->p->c4 == NULL)  item->p->c4 = createNode(key,-1,-1,item->p);
          else item->p->c4->val1 = key;
          item->p->c4->val2 = item->val3;
          item->p->c4->val3 = -1;
          item->val3 = -1;
        }else if(key>item->val3  && item->val3!=-1){
          if(item->p->c4 == NULL)  item->p->c4 = createNode(item->val3,-1,-1,item->p);
          else item->p->c4->val1 = item->val3;
          item->p->c4->val2 = key;
          item->val2 = -1;
          item->val3 = -1;
        }
        match = 0;
        return item;
      }
      match = 0;
      return item;
   }
    ins=0;
    return item;
}

void search(int key,struct node* item){
     static int found =0;
     static int in =0;
     int leaf =0;
     if(item->c1 == NULL && item->c2 == NULL && item->c3 == NULL && item->c4 == NULL ) leaf=1;
     if(key<item->val1  && !found) {
      if(item->c1 != NULL){
         in=1;
         search(key,item->c1);
      }
     }
     if(item->val2 == -1 && item->val3 == -1 && key>item->val1  && !found ){
      if(item->c2 != NULL) { 
        in=1;
        search(key,item->c2);
      }
     }
     if(key>item->val3  && item->val3 != -1  && !found) {
      if(item->c4 != NULL){
          in =1;
         search(key,item->c4);
      }
     }
     if(key>item->val1 && key<item->val2 && item->c2 != NULL  && item->val2 != -1   && !found ){
       if(item->c2 != NULL){
         in=1;
         search(key,item->c2);
       }
     } 
     if(key>item->val2 && key<item->val3 && item->c3 != NULL  && item->val3 != -1 && !found ){
      if(item->c3 != NULL) {
        in=1;
        search(key,item->c3);
      }
     }
       if(key == item->val1 && !found) {
        found = 1;
        printf("%d found \n ",key);
        if(!in) found =0;
        return;
       }
       if(key == item->val2  && !found) {
        found = 1;
        printf("%d found \n ",key);
        if(!in) found =0;
        return;
      }
      if(key == item->val3  && !found) {
        found = 1;
        printf("%d found \n ",key);
        if(!in) found =0;
        return;
      }
      if(!found && !leaf){
        search(key,item->c1);
        in=1;
      }if(!found && !leaf){
        search(key,item->c2);
         in=1;
      }if(!found && !leaf){
        search(key,item->c3);
         in=1;
      }if(!found && !leaf){
        search(key,item->c4);
         in=1;
      }
     if(found == 0 && in==0) printf("%d not found \n",key);
     found=0;
     in =0;
     return;
}
struct node* print(struct node* item){
       if(item->val1 != -1) printf("|%d|",item->val1);
       if(item->val2 != -1) printf("%d|",item->val2);
       if(item->val3 != -1) printf("%d| ",item->val3);
      if(item->c1 != NULL){
         printf("\n");
         print(item->c1);
      }
       if(item->c2 != NULL) {
        printf("  ");
        print(item->c2);
       }      
       if(item->c3 != NULL){
         printf("  ");
         print(item->c3);
       }
       if(item->c4 != NULL){
        printf("  ");
        print(item->c4);
        printf("\n");
      }
        return item;
}
int main(){
    int num;
    scanf("%d", &num);
    int string[num];
    for(int i=0;i<2*num;i=i+2){
     if(i%2 == 0) scanf(" %d",&string[(i/2)]);
    }
    struct node* root = insert(string[0],NULL);
    for(int i=1;i<num;i++){
      root = insert(string[i],root);
     }
     struct node* tree;
     while(1){
     int array[2];
     for(int i=0;i<4;i=i+2){
       if(i%2 == 0) scanf(" %d",&array[(i/2)]);
     }
     if(array[0] ==1){
       search(array[1],root);
       printf("\n");
     }
     if(array[0] ==2) {
      root = insert(array[1],root);
      printf("\n");
     }
     if(array[0] == 4){ 
             tree = print(root);
             printf("\n");
     }
     }
    // root = insert(8,root);
    // root = insert(5,root);
    //  root = insert(4,root);
    //  root = insert(99,root);
    //  root = insert(78,root);
    //  root = insert(31,root);
    //  root = insert(34,root);
    //  root = insert(89,root);
    return 0;
}