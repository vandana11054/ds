

#include <stdio.h>
// #include<stdlib.h>
int main()
{
   int num;
   scanf("%d",&num);
   char* str[num];
   gets(str[0]);
   printf("%s \n",str[0]);
   return 0;
}