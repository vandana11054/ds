
/*Program for search and insertion in a 2-4 tree*/

**Input format:**
  Program will run in an infinite loop with corresponding inputs in order:
  line-1 : contains number of elements to be inserted into 2-4 tree at a time.(say n)
  line-2 : A string with those n elements seperated by a single space.
  line-3 : An instruction of form:  int int [Two integers seperated by a single space] 
           first integer specifies  operation [1 for search,2 for insert,4 for print] 
           for print operation please enter 4 0 
           second integer is value of operand.
           This kind of input can be given on and on until stop of code execution using Ctrl+c key(or any diff. combination of keys to stop execution)

**Output:**
   Out of the program is shown by entering 4 (prints the tree) on and after line-3 of input.

**Limitations:**
  1.Searching elements which are in corner-most positions first returns not found then found message if element is present in the tree.Kindly consider that if "found" keyword is showing up for any element even if few 'not found' statements are there that element is present in the tree.
  2. Few input cases are not being inserted correctly by this code.   