

#include<stdio.h>
int sort[15];        
int * Heapify(int* A,int n){      //given an array of integers it's converted to heap
    for(int k = (int)n/2;k>0;k=(int)k/2){
        for(int i=0;i<(int)(k);i=i+2){
             int low=0;
             char high ='0';
         if(A[k+i]<=A[k+i+1] && A[k+i]!=0)  //compare two child notes and store low
             low = A[k+i];
         else{
            if(A[k+i+1]!=0){
            low = A[k+i+1];
            high = '1';
         }
         }
         if(A[(k+i)/2] > low){
           int temp=0;
                 if(high=='1'){
                    temp = A[k+i+1];          //swap parent and low according to values.
                    A[k+i+1] = A[(k+i)/2];
                    A[(k+i)/2] = temp;
                 }else{
                     temp = A[k+i];
                     A[k+i] = A[(k+i)/2];
                     A[(k+i)/2] = temp;
                 }
         }
        }
     }

     return A;
}
 int * Delete_Min(int * arr,int n,int i ){    //min element of heap is deleted and written to sort array
      sort[i] = arr[0];
      arr[0]= arr[n-1];
      arr[n-1]= 0;
      return arr;
 }
int main(){
    int arr[30];
    for(int i=0;i<15;i++){
        scanf(" %d",&arr[i]);
    }
  
    *arr = * Heapify(arr,15); //given array converted to heap
    for(int i=0;i<15;i++){
       *arr = * Delete_Min(arr,15-i,i);    //Whole heap is undergone sort
       *arr = * Heapify(arr,14-i);
    }
        for(int i=0;i<15;i++){
         if(sort[i]==0) break;
         printf(" %d",sort[i]);
    }
}