

*input*
 for given tree input  is hardcoded in the program.
 inserted  9, 8, 5, 4, 99, 78, 31, 34, 89, 90, 21, 23, 45, 77, 88, 112, 32 to avl tree
 deleted   88,9 from tree
 prompted error for deleting nodes that are not existing in the tree
 external input can be given as:
           root = insert(root,value);
           root = delete(root,value);
           
 *output*
 preorder at every stage printed on console

 ## Instructions for running:
    gcc avldel.c -o avldel
    ./avldel
