
//Program to insert and delete nodes from an avl tree
#include<stdio.h>
#include<stdlib.h>

struct node{
    int key;               // struct element for storing every node
    int height;
    struct node* left;
    struct node* right;
};

struct node* createNode(struct node* item,int key){         //create node given key value
      struct node* one = (struct node *)malloc(sizeof(struct node));
      one->key = key;
      one->height = 1;            //allocation of memory and default initialisation
      one->left = NULL;
      one->right = NULL;
      item = one;                 // given pointer is updated with properties
      return item;
}

int getHeight(struct node* item){
    if(item == NULL) return 0;
    return item->height;         // height of node returned
}

int balance(struct node* item){
    if(item == NULL) return 0;
    int leftheight  =   (item->left  ? getHeight(item->left) : 0); //if item->left not empty then it's height
    int rightheight =   (item->right ? getHeight(item->right): 0); //if item->right not empty then it's height
    return (leftheight - rightheight);
}

struct node* minValue(struct node* item){
    struct node * curr = item;          //Function to calculate left most node from given node
    while(curr->left != NULL){
        return minValue(curr);
    }
    return curr;
}

int max(int a,int b){
     return ( a>b ? a : b ); 
}

struct node* rightRotate(struct node* item){  //Rightrotation of a node which is imbalanced
        struct node* temp = item->left;
        struct node* T = temp->right;
        temp->right = item;
        item->left = T;
        item->height = 1 + max(getHeight(item->left),getHeight(item->right)); //Update heights
        temp->height = 1 + max(getHeight(temp->left),getHeight(temp->right));
        return temp;                     // root after rotation returned
}

struct node* leftRotate(struct node* item){ //leftrotation of a node which is imbalanced
        struct node* temp = item->right;
        struct node* T = temp->left;  
        temp->left = item;
        item->right = T;
        item->height = 1 + max(getHeight(item->left),getHeight(item->right)); //Update heights
        temp->height = 1 + max(getHeight(temp->left),getHeight(temp->right));
        return temp;                    // root after rotation returned
}

struct node* insert(struct node* item,int key){
     if(item == NULL) {
         item = createNode(item,key);       //create node if root is null
         return item;
     }
     if(key < item->key){                    //as avl tree is bst 
        item->left = insert(item->left,key); //lesser values are stored in left nodes 
     }
     else if(key > item->key){
         item->right = insert(item->right,key); //greater values are stored in right nodes
     }
      item->height = 1 + max(getHeight(item->left),getHeight(item->right)); //Update height of given node
      int bf = balance(item);          //balance factor of node returned
        //necessary rotations for avl conditions:
         if(bf>1 && key < item->key){  //Left-left insertion
              return rightRotate(item);
         } 
         if(bf<-1 && key > item->key){  //Right-right insertion
              return leftRotate(item);
         } 
         if(bf>1 && key > item->key){   //Left-right insertion
              item->left = leftRotate(item->left);
              return rightRotate(item);
         } 
         if(bf<-1 && key < item->key){     //Right-left insertion
              item->right = rightRotate(item->right);
              return leftRotate(item);
         } 
         return item;                //after complete insertion return node
}

void preorder(struct node* item){
    if(item == NULL) return; 
    printf("%d  ",item->key);  // print root node of given subtree
    preorder(item->left);      // go to left node
    preorder(item->right);     // go to right node
}

struct node* delete(struct node *item,int key){
    static int exists =1;
    if(item == NULL) {               //statement for not exists
        if(exists!=1)  printf(" ERROR: %d not found in the tree \n",key); 
        return item;  
        }                     
    if(key < item->key) {            //lesser values are stored in left nodes
        item->left = delete(item->left,key);  //recursive call
    }
    else if(key > item->key) {       //greater values are stored in right nodes
        item->right = delete(item->right,key); //recursive call 
    }
    else{ //in recursion arrived at item->key = key condition
        if( item->left == NULL || item->right == NULL){ //if one of the child is null
            struct node* temp = (item->left) ? item->left : item->right;  //check for other child is present or not 
            if(temp == NULL){ 
                temp = item;  
                item = NULL;
            }else{
                *item = *temp;      // if one child is present send it's value to item     
            }
            free(temp);
        }
        else{        //if two children are present
            struct node* temp = minValue(item->right);   //go to left most child of right subtree
            item->key = temp->key;                       //copy key value to item->key
            item->right = delete(item->right,temp->key); //delete temp->key from tree recursive call
        }
    }
        if(item == NULL){  //after deleting check if item is null and return to caller
            exists--;      //updating to check only given element is present in tree or not  
            return item;
        }
         item->height = 1 + max(getHeight(item->left),getHeight(item->right)); // Update height of node
         int bf = balance(item);  //balance factor of given node calculated
        //necessary rotations for avl conditions:
         if(bf>1 && balance(item->left)>=0){
             return rightRotate(item);  //left-left case
         }
         if(bf<-1 && balance(item->right)<=0){
             return leftRotate(item);  //right-right case
         }
         if(bf>1 && balance(item->left)<0){
              item->left = leftRotate(item->left);  //left-right case
              return rightRotate(item);
         }
         if(bf<-1 && balance(item->right)>0){
             item->right = rightRotate(item->right); //right-left case
             return leftRotate(item);
         }
         return item;  //after deletion return node
}
int main(){
    struct node * root = NULL;
      root =   insert(root,9);
      root =   insert(root,8);
      root =   insert(root,5);
      root =   insert(root,4);            //inserting 9, 8, 5, 4, 99, 78, 31, 34, 89, 90, 21, 23, 45, 77, 88, 112, 32.
      root =   insert(root,99);
      root =   insert(root,78);
      root =   insert(root,31);
      root =   insert(root,34);
      root =   insert(root,89);
      root =   insert(root,90);
      root =   insert(root,21);
      root =   insert(root,23);
      root =   insert(root,45);
      root =   insert(root,77);
      root =   insert(root,88);
      root =   insert(root,112);
      root =   insert(root,32);
      preorder(root);
      printf("     (preorder of tree before deletion) \n");
      root = delete(root,88);            //deleting 88
      preorder(root);
      printf("  (deleted 88) \n   ");
      root = delete(root,9);             //deleting 9
      preorder(root);
      printf("  (deleted 9)   \n  ");
      root =  delete(root,71);           //delete function with parameter 71
      preorder(root);
      printf("  (current tree) \n ");
      root =  delete(root,67);           //delete function with parameter 67
      preorder(root); 
      printf("  (current tree)  ");
}