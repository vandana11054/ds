

**Input format:**
  Input is expected as a continous string of integers.
  constraint: 
  hardcoded input size to 15
  Extra condition that heap will not contain 0

   **Output**:
    Sorted heap of integers
              
               